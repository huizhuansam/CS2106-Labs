char *findPerson(char *);
void addPerson(char *, char *);
void delPerson(char *);
void print_phonebook();
void delPhonebook();
