
double sum(int [], int);
